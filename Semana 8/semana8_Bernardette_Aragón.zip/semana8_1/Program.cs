﻿public class ClaseSemana8Actividad1
{
public static void Main()
{
    int numero;
    string entrada;
    while (true)
        {
            Console.Write("Ingrese un número válido: ");
            entrada = Console.ReadLine();
 
            if (int.TryParse(entrada, out numero))
            {
                break;
            }
            else
            {
                Console.WriteLine("Entrada inválida. Inténtalo de nuevo.");
            }
        }

        ClaseSemana8Actividad1 instance = new ClaseSemana8Actividad1();
        int resultado = instance.CalcularFactorial(numero);
        Console.WriteLine($"El factorial de {numero} es {resultado}");
}

    public int CalcularFactorial(int numero)
{
    if (numero == 0)
    {
        return 1 ;
    }
    else
    { 
    int factorial = 1;
    for (int i = 1; i <= numero; i++)
    {
        factorial *= i;
    }
    return factorial;
    }
}
 
}
  
