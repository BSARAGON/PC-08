﻿class actividad1_semana9_b
{
    static void Main()
    {
        int numero;
        string entrada;

        while (true)
        {
            Console.Write("Ingrese un número entero positivo: ");
            entrada = Console.ReadLine();

            if (int.TryParse(entrada, out numero) && numero >= 0)
            {
                break; 
            }
            else
            {
                Console.WriteLine("Entrada inválida. Inténtalo de nuevo.");
            }
        }

        bool esPrimo = true;

        if (numero < 2)
        {
            esPrimo = false; 
        }
        else
        {
            for (int i = 2; i < numero; i++) 
            {
                if (numero % i == 0)
                {
                    esPrimo = false; 
                    break; 
                }
            }
        }

        if (esPrimo)
            Console.WriteLine($"{numero} es un número primo.");
        else
            Console.WriteLine($"{numero} no es un número primo.");
    }
}